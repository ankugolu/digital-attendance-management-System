<?php include_once("connection.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.min.css">
	<script src="bootstrap/bootstrap.min.js"></script>
	<script src="bootstrap/jquery.min.js"></script>
	 


</head>
<body background="rail.jpg">



<div class="panel panel-default container">

<div class="panel-heading">
	
	<h1 style="text-align: center;">Attendance Mangement System</h1>

</div>
	

<div class="panel-body">
	<a href="profile2.php" class="btn btn-primary">Back</a>
	<a href="admin_check.php" class="btn btn-primary pull-right">LOGOUT</a>
	
<form method="post">
<table class="table">
	

<thead>
	
<tr>
	<th>Name</th>
	<th>Email</th>
	<th>Attendance</th>
</tr>


</thead>



<tbody>
	

<?php 

			$query="select * from register";
			$result=$link->query($query);
			while($show=$result->fetch_assoc()){




 ?>

<tr>
	<td><?php echo $show['name']; ?></td>
	<td><?php echo $show['email']; ?></td>
	<td>
		
		Present <input required type="radio" name="attendance[<?php echo $show['user_id'] ?>]" value="Present">Absent <input required type="radio" name="attendance[<?php echo $show['user_id']; ?>]" value="Absent" type="text">


	</td>
</tr>
<?php } ?>




</tbody>




<?php 

			if($_SERVER['REQUEST_METHOD']=='POST'){
				$att=@$_POST['attendance'];
				$date=date('d-m-y');

				$query="select distinct date from attendance";
				$result=$link->query($query);
				$b=false;
				if($result->num_rows>0){
				while($check=$result->fetch_assoc()){
					
					if($date==$check['date']){
					$b=true;
					echo "<div class='alert alert-danger'>
						
						Attendance already taken today!!!;

					</div>"; 
				}
				}
			}


					if(!$b){
							foreach ($att as $key => $value) {
								
								if($value=="Present"){

										$query="insert into attendance(user_id,value,date) values($key,'Present','$date')";
										$insertResult=$link->query($query);



								}
								else {

											$query="insert into attendance(user_id,value,date) values($key,'Absent','$date')";
										$insertResult=$link->query($query);
										




								}



							}

							if($insertResult){
								echo "<div class='alert alert-success'>
						
						Attendance  taken successfully!!!;

					</div>"; 
							}

					}

				

			


			}


 ?>

</table>
<a href="view.php" class="btn btn-primary">View</a>
<input class="btn btn-primary pull-right" type="submit" value="Take Attendance">
</form>


</div>
	

<div class="panel-footer">
	
	
</div>
	

</div>

</body>
</html>