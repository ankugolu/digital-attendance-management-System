<?php
define("DBHOST","localhost");
define("DBUSERNAME","root");
define("DBPASSWORD","");
define("DB","project");

$con = mysqli_connect(DBHOST,DBUSERNAME,DBPASSWORD,DB);
if($con){
	echo "connect"."<br>";
}
else{
	echo "not connect";
}
if($_SERVER['REQUEST_METHOD']=="POST"){
	$name= $_POST['name'];
	$dob = $_POST['date'];
	$address = $_POST['add'];
	$mobile= $_POST['mob'];
	$gender = $_POST['rad'];
	$email = $_POST['em'];
	$qualification= $_POST['hq'];
	$password = $_POST['pass'];
	
	
	$sql = "Insert into register(name,dob,address,mobile,gender,email,qualification,password)values('".$name."','".$dob."','".$address."','".$mobile."','".$gender."','".$email."','".$qualification."','".md5($password)."')";
	mysqli_query($con,$sql);
	
	echo "Successfully Inserted data!";
	header("Location:register.php");
}
?>
	
<!DOCTYPE html>
<html>
<head>
<!DOCTYPE html>
<html>
<head>
<link href="https://fonts.googleapis.com/css?family=Bitter" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
font-family: 'Bitter', serif;
}

.sidenav {
height: 100%;
width: 0;
position: fixed;
z-index: 1;
top: 0;
left: 0;
background-color: #111;
overflow-x: hidden;
transition: 0.5s;
padding-top: 60px;
}

.sidenav a {
padding: 8px 8px 8px 32px;
text-decoration: none;
font-size: 25px;
color: #818181;
display: block;
transition: 0.3s;
}

.sidenav a:hover {
color: #f1f1f1;
}

.sidenav .closebtn {
position: absolute;
top: 0;
right: 25px;
font-size: 36px;
margin-left: 50px;
}

@media screen and (max-height: 450px) {
.sidenav {padding-top: 15px;}
.sidenav a {font-size: 18px;}
}
</style>
</head>
<body background="pictures/tan.jpg">
<div id="mySidenav" class="sidenav">
 <a href="javascript:void(0)" class="closebtn" onClick="closeNav()">&times;</a>
 <a href="index.php">Home</a> 
  <a href="about.php">About</a>
   <a href="users.php">Users/Actors</a>
    <a href="overview.php">Overview</a>
		 <a href="requirement.php">System Requirement</a>
	 <a href="contact.php">Contact</a>
	 	 <a href="#">----------------</a>
		 <a href="login.php">LOGIN</a>
		  
		 
	 
	  </div>

<span style="font-size:30px;cursor:pointer" onClick="openNav()">&#9776; MENU</span>
<script>
function openNav() {
document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
document.getElementById("mySidenav").style.width = "0";
}
</script>

<div style="background-color: white" style="background:url(pictures/tan.jpg)">
  <label>
  <div style="background:url(pictures/tan.jpg)"><h1 align="center" style="background:url(pictures/tan.jpg)"><u>*****WELCOME TO EMPLOYEE REGISTRATION PORTAL*****</u></h1>
  </div>
   <div style="background:url(pictures/tan.jpg)"><hr><font color="red" size="6"><marquee behavior="alternate">............!!!!!!PLEASE ENTER YOUR DATA CAREFULLY!!!!!!............</marquee></hr></div>
  </label>
</div>
<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>User Registration Portal</title>
</head>
<body>

<form name="task" method="POST" enctype="multipart/form-data">
	<table border="5" align="center" style="border-color: black">
		<col width="400">
		<tr>
			<td colspan="3">
				<h3 align="center"><b>REGISTRATION FORM</b></h3>
			</td>
		</tr>
		<tr>
			<td>
				<label style="font-size: 14pt"><b>NAME:-</b></label>
			</td>
			<td colspan="3">
				<input type="text" style="font-size: 14pt;" name="name" placeholder="INSERT YOUR NAME" required="required">
			</td>
		</tr>
		<tr>
		<td>
		<label style="font-size:14px"><b>DATE</b></label>
		</td>
		<td>
		<input type="date" name="date">
		</td>
		</tr>
		<tr>
			<td>
				<label style="font-size: 14pt"><b>ADDRESS:-</b></label>
			</td>
			<td colspan="3">
				<textarea style="font-size: 14pt;" name="add" placeholder="INSERT YOUR ADDRESS" rows="5" cols="45" required="required"></textarea>
			</td>
		</tr>
		<tr>
			<td>
				<label style="font-size: 14pt"><b>MOBILE NUMBER:-</b></label>
			</td>
			<td>+91</td>
			<td>
				<input type="text" style="font-size: 14pt;" name="mob" placeholder="0000000000" required="required">
			</td>
		</tr>
		<tr>
			<td>
				<label style="font-size: 14pt"><b>GENDER:-</b></label>
			</td>
			<td colspan="3">
				<input type="radio" name="rad" value="MALE" checked>MALE
				<input type="radio" name="rad" value="FEMALE">FEMALE
				<input type="radio" name="rad" value="OTHERS">OTHERS
			</td>
		</tr>
		<tr>
			<td>
				<label style="font-size: 14pt"><b>EMAIL ID:-</b></label>
			</td>
			<td colspan="3">
				<input type="text" style="font-size: 14pt;" name="em" placeholder="abc@example.com" required="required">
			</td>
		</tr>
		<tr>
			<td>
				<label style="font-size: 14pt"><b>QUALIFICATION:-</b></label>
			</td>
			<td colspan="3">
				<select name="hq">
					<option name="opt" value="B.Tech">B.Tech</option>
					<option name="opt" value="B.Sc">B.Sc</option>
					<option name="opt" value="BBA">BBA</option>
					<option name="opt" value="B.MATH">B.MATH</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>
				<label style="font-size: 14pt"><b>CHOOSE PASSWORD:-</b></label>
			</td>
			<td colspan="3">
				<input type="password" style="font-size: 14pt;" name="pass" required="required">
			</td>
		</tr>
		
	</table>
	<div  align="center">
	<input type="submit" value="SUBMIT">
	</div>
</form>
</body>
</html>