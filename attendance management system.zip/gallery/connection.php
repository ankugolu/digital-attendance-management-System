<?php 
$host="localhost";
$dbName="project";
$user="root";
$pass="";

$link=new mysqli($host,$user,$pass,$dbName);
if($link)
{
echo "connect";
}
else
{
echo "not connect";
}
?>
