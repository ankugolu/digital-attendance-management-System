<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!DOCTYPE html>
<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
font-family: "Lato", sans-serif;
}

.sidenav {
height: 100%;
width: 0;
position: fixed;
z-index: 1;
top: 0;
left: 0;
background-color: #111;
overflow-x: hidden;
transition: 0.5s;
padding-top: 60px;
}

.sidenav a {
padding: 8px 8px 8px 32px;
text-decoration: none;
font-size: 25px;
color: #818181;
display: block;
transition: 0.3s;
}

.sidenav a:hover {
color: #f1f1f1;
}

.sidenav .closebtn {
position: absolute;
top: 0;
right: 25px;
font-size: 36px;
margin-left: 50px;
}

@media screen and (max-height: 450px) {
.sidenav {padding-top: 15px;}
.sidenav a {font-size: 18px;}
}
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
 <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
 <a href="index.php">Home</a>
  <a href="about.php">About</a>
   <a href="users.php">Users/Actors</a>
    <a href="overview.php">Overview</a>
		 <a href="requirement.php">System Requirement</a>
	 
	 	 <a href="#">----------------</a>
		 <a href="login.php">login</a>
		  <a href="register.php">register</a>
		  
		 
	 
	  </div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; MENU</span>
<script>
function openNav() {
document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
document.getElementById("mySidenav").style.width = "0";
}
</script>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}
</style>
</head>
<body>

<table border="5" align="center" style="border-color: black">
	<col width="700">
	
	
	<tr>
			<td colspan="3">
				<label style="font-size: 20pt"  ><h3 align="center" ><b>CONTACTS OF THE TEAM</b></h3></label>
			</td>
		</tr>
</table>
<div class="card">
  <img src="pictures/hihi.jpeg" alt="img" style="width:100%">
  <h1>Tanmay Karmakar</h1>
  <p>+91-9734446071</p>
  <p>karmakartanmay980@gmail.com</p>
  <p>Imps College Of Engineering & Technology</p>
  <div style="margin: 24px 0;">
    
 </div>

</div>
<div class="card">
  <img src="pictures/ankur.jpeg" alt="img" style="width:100%">
  <h1>Ankur Kumar Agarwal</h1>
  <p>+91-8906231910</p>
  <p>ankuragarwal740@gmail.com</p>
  <p>Imps College Of Engineering & Technology</p>
  <div style="margin: 24px 0;">
    
 </div>
</div>
<div class="card">
  <img src="pictures/anshu.jpeg" alt="img" style="width:100%">
  <h1>Anshumali shaw</h1>
  <p>+91-8697530601</p>
  <p>shaw.anshu@gmail.com</p>
  <p>Government College Of Engineering & Textile Technology</p>
  <div style="margin: 24px 0;">
    
 </div>

</div>
<div class="card">
  <img src="pictures/nndn.jpeg" alt="img" style="width:100%">
  <h1>Nandan Saha</h1>
  <p>+91-7029406883</p>
  <p>sahanandan1000@gmail.com</p>
  <p>Imps College Of Engineering & Technology</p>
  <div style="margin: 24px 0;">
    
 </div>
<div class="card">
  <img src="pictures/tnny.jpeg" alt="img" style="width:100%">
  <h1>Tanny Banerjee</h1>
  <p>+91-9123220981</p>
  <p>tannybanerjee282@gmail.com</p>
  <p>Bengal Institute Of Technology & Management</p>
  <div style="margin: 24px 0;">
    
 </div>
<div class="card">
  <img src="pictures/pranjal.jpeg" alt="img" style="width:100%">
  <h1>Pranjal Gain</h1>
  <p>+91-9800384120</p>
  <p>pranjalgain052@gmail.com</p>
  <p>Government College Of Engineering & Textile Technology</p>
  <div style="margin: 24px 0;">
    
 </div>
<div class="card">
  <img src="pictures/rupam.jpeg" alt="img" style="width:100%">
  <h1>Rupam Haldar</h1>
  <p>+91-7063615936</p>
  <p>rupamhaldar06@gmail.com</p>
  <p>Government College Of Engineering & Textile Technology</p>
  <div style="margin: 24px 0;">
    
 </div>

</body>
</html>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<body>
<html>
<body background="pictures/images.jpg">


<form name="task" method="POST">
	
				</form>
</body>
</html>
