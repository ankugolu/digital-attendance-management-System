<?php include_once("connection.php");
include('session.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.min.css">
	<script src="bootstrap/bootstrap.min.js"></script>
	<script src="bootstrap/jquery.min.js"></script>
</head>
<body background="head.jpg">



<div class="panel panel-default container">

<div class="panel-heading">
	
	<h1 style="text-align: center;">Attendance Mangement System</h1>

</div>
	

<div class="panel-body">
	
<a href="profile.php" class="btn btn-primary">Back</a>	
	<a href="logout.php" class="btn btn-primary pull-right">Logout</a>
<form method="post">
<table class="table">
	

<thead>
	
<tr>
	<th>Sr No.</th>
	<th>Email</th>
	<th>Date</th>
	<th>View</th>
</tr>


</thead>

			<?php 

				$query="select * from attendance group by date";
				$result=$link->query($query);
				
				

				if($result->num_rows>0){
					$i=0;
					while ($val=$result->fetch_assoc()) {
					
						//echo "<pre>"; print_r($val);
						$i++;


			 ?>

<tr>
	
	<td><?php echo $i; ?></td>
	<td><?php echo $login_session; ?></td>

	<td><?php echo $val['date']; ?></td>

	<td><?php echo $val['value'] ?></td>


</tr>
<?php } } ?>



</div>
	

<div class="panel-footer">
	
	
</div>
	

</div>

</body>
</html>