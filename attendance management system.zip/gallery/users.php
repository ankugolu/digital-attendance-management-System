<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
font-family: "Lato", sans-serif;
}

.sidenav {
height: 100%;
width: 0;
position: fixed;
z-index: 1;
top: 0;
left: 0;
background-color: #111;
overflow-x: hidden;
transition: 0.5s;
padding-top: 60px;
}

.sidenav a {
padding: 8px 8px 8px 32px;
text-decoration: none;
font-size: 25px;
color: #818181;
display: block;
transition: 0.3s;
}

.sidenav a:hover {
color: #f1f1f1;
}

.sidenav .closebtn {
position: absolute;
top: 0;
right: 25px;
font-size: 36px;
margin-left: 50px;
}

@media screen and (max-height: 450px) {
.sidenav {padding-top: 15px;}
.sidenav a {font-size: 18px;}
}
</style>
</head>
<body>
<div id="mySidenav" class="sidenav">
 <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
 <a href="index.php">Home</a>
   <a href="about.php">About</a>
    <a href="overview.php">Overview</a>
		 <a href="requirement.php">System Requirement</a>
	 <a href="contact.php">Contact</a>
	 	 <a href="#">----------------</a>
		 <a href="login.php">login</a>
		  <a href="register.php">register</a>
		  
		 
	 
	  </div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; MENU</span>
<script>
function openNav() {
document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
document.getElementById("mySidenav").style.width = "0";
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>User/Actors of the project</title>
</head>
<body background="pictures/tan.jpg">
<form name="task" method="POST">
	<table border="5" align="center" style="border-color: black">
	<col width="700">
	<tr>
	<td>
	</td>
	</tr>
	<tr>
	<td>
	</td>
	</tr>
	
	
	<tr>
			<td colspan="">
				<label style="font-size: 20pt"><h3 align="center"><b>Users/Actors of the Project</b></h3></label>
			</td>
		</tr>
		<tr>
			<td>
				<label style="font-size: 14pt"><b>
				
				
 
Teacher
</td>
</tr>
<tr>
<td>
He/she is required to create account and then gets approved by the admin.
</td>
</tr>
<tr>
<td>
Teacher can Choose/assigned Multiple lectures.
</td>
</tr>
<tr>
<td>
Teacher can Manage Multiple lectures multiple students Attendance.
</td>
</tr>
<tr>
<td>
View the list of students assigned to them.
</td>
</tr>
<tr>
<td>
Mark attendance after each lecture
</td>
</tr>
<tr>
<td>
View attendance of each student assigned to them.</td>
</tr>
<tr>
<td>
Generate/Download Report of attendance in PDF Format</td>
</tr>
<tr>
<td>
Check Average Attendance</td>
</tr>
<tr>
<td>
Update Profile</td>
</tr>
<tr>
<td>
Upload Profile Pic</td>
</tr>
<tr>
<td>
Update Password(encrypted format)</td>
</tr>
<tr>
<td><label style="font-size: 14pt"><b>


Student</td>
</tr>
<tr>
<td>

He/she needs to create an account.
</td>
</tr>
<tr>
<td>
Students can register himself/herself for Multiple lectures.
</td>
</tr>
<tr>
<td>
Students can Check Attendance for Multiple lectures.
</td>
</tr>
<tr>
<td>
Can view their attendance from anywhere around the globe.
</td>
</tr>
<tr>
<td>
Generate/Download Report of attendance in PDF Format</td>
</tr>
<tr>
<td>
Check Average Attendance</td>
</tr>
<tr>
<td>
Update Profile</td>
</tr>
<tr>
<td>
Upload Profile Pic</td>
</tr>
<tr>
<td>
Update Password(encrypted format)
</b></label>
				</td></tr>
				<tr>
				<td>
				</td>
				</tr>
				<tr>
				<td>
				</td>
				</tr>
				</table>
</body>
</html>
