<?php

//include();
session_start(); // Starting Session
$conn = mysqli_connect("localhost", "root", "", "project");
$error = ''; // Variable To Store Error Message

if (isset($_POST['submit'])) {
if (empty($_POST['email']) || empty($_POST['password'])) {
$error = "Email_id or Password is invalid";
}
else
{
// Define $username and $password
$email = $_POST['email'];
$password = md5($_POST['password']);

// mysqli_connect() function opens a new connection to the MySQL server.


// SQL query to fetch information of registerd users and finds user match.
$query = "SELECT email, password from register where email='".$email."' AND password='".$password."'";
$result = mysqli_query($conn,$query);
$data = mysqli_fetch_assoc($result);
print_r("$data");
if(count($data)>0){
	 $_SESSION['login_register'] = $email; // Initializing Session
          header("location: profile.php"); // Redirecting To Profile Page

}
else {
   $error = "Email_id or Password is invalid";
 }


// To protect MySQL injection for Security purpose
/*$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $email, $password);
$stmt->execute();
$stmt->bind_result($email, $password);
$stmt->store_result();

if($stmt->fetch()) //fetching the contents of the row
        {
          $_SESSION['login_register'] = $email; // Initializing Session
          header("location: profile.php"); // Redirecting To Profile Page
        }
else {
       $error = "Email_id or Password is invalid";
     }*/
mysqli_close($conn); // Closing Connection
}
}
?>
