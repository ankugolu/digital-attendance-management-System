<?php
include('login1.php'); // Includes Login Script
if(isset($_SESSION['login_register'])){
header("location: profile.php"); // Redirecting To Profile Page
}
?> 

<!DOCTYPE html>
<html>
<head>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
font-family: "Lato", sans-serif;
}

.sidenav {
height: 100%;
width: 0;
position: fixed;
z-index: 1;
top: 0;
left: 0;
background-color: #111;
overflow-x: hidden;
transition: 0.5s;
padding-top: 60px;
}

.sidenav a {
padding: 8px 8px 8px 32px;
text-decoration: none;
font-size: 25px;
color: #818181;
display: block;
transition: 0.3s;
}

.sidenav a:hover {
color: #f1f1f1;
}

.sidenav .closebtn {
position: absolute;
top: 0;
right: 25px;
font-size: 36px;
margin-left: 50px;
}

@media screen and (max-height: 450px) {
.sidenav {padding-top: 15px;}
.sidenav a {font-size: 18px;}
}
</style>
</head>
<body background="pictures/tan.jpg">
<div id="mySidenav" class="sidenav">
 <a href="javascript:void(0)" class="closebtn" onClick="closeNav()">&times;</a>
  <a href="index.php">Home</a>
  <a href="about.php">About</a>
   <a href="users.php">Users/Actors</a>
    <a href="overview.php">Overview</a>
		 <a href="requirement.php">System Requirement</a>
	 <a href="contact.php">Contact</a>
	 	 <a href="#">----------------</a>
		  
		  
		  <a href="register.php">register</a>
	 
	  </div>

<span style="font-size:30px;cursor:pointer" onClick="openNav()"><font color="black">&#9776; MENU</span>
<script>
function openNav() {
document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
document.getElementById("mySidenav").style.width = "0";
}
</script>

  <title>Login Portal</title>
  <link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>

 <div id="login">
  <h2>Employee Login Form</h2>
  <form action="" method="post">
   <label>UserName :</label>
   <input id="name" name="email" placeholder="enter your email" type="text">
   <label>Password :</label>
   <input id="password" name="password" placeholder="**********" type="password"><br><br>
   <input name="submit" type="submit" value=" Login ">
   <span><?php echo $error; ?></span>
  </form>
 </div>
</body>
</html>