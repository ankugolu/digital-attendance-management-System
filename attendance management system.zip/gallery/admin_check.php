<html>
<head>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
font-family: "Lato", sans-serif;
}

.sidenav {
height: 100%;
width: 0;
position: fixed;
z-index: 1;
top: 0;
left: 0;
background-color: #111;
overflow-x: hidden;
transition: 0.5s;
padding-top: 60px;
}

.sidenav a {
padding: 8px 8px 8px 32px;
text-decoration: none;
font-size: 25px;
color: #818181;
display: block;
transition: 0.3s;
}

.sidenav a:hover {
color: #f1f1f1;
}

.sidenav .closebtn {
position: absolute;
top: 0;
right: 25px;
font-size: 36px;
margin-left: 50px;
}

@media screen and (max-height: 450px) {
.sidenav {padding-top: 15px;}
.sidenav a {font-size: 18px;}
}
</style>
</head>
<body>
<div id="mySidenav" class="sidenav"> 
<a href="javascript:void(0)" class="closebtn" onClick="closeNav()">&times;</a>
 <a href="index.php">Home</a> 
 <a href="about.php">About</a> 
 <a href="users.php">Users/Actors</a>
  <a href="overview.php">Overview</a> 
  <a href="requirement.php">System Requirement</a>
   <a href="contact.php">Contact</a>
    <a href="#">----------------</a> </div>
<span style="font-size:30px;cursor:pointer" onClick="openNav()"><font color="black">&#9776; MENU</span>
<script>
function openNav() {
document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
document.getElementById("mySidenav").style.width = "0";
}
</script>
<title>ADMIN</title>
<link rel="stylesheet" href="body1.css" >
</head>
<body background="mountain.jpg" >
<div align="center" >
  <h1><u>ADMIN</u></h1>
</div>
<h3 align="center" >Please verify if ADMIN</h3>
<form name="log" method="POST">
  <table border="5"  align="center">
    <tr>
      <td><h4>USERNAME:-</h4></td>
      <td colspan="3"><input type="text" name="em1" style="font-size: 14pt" >
      </td>
    </tr>
    <tr>
      <td><h4>PASSWORD:-</h4></td>
      <td colspan="3"><input type="password" name="ps1" style="font-size: 14pt">
      </td>
    </tr>
  </table>
  <div align="center">
    <input type="submit" class="button" name="LOGIN">
  </div>
</form>
<div align="center" >
  <?php
if($_SERVER['REQUEST_METHOD']=='POST')
{
$e="aDMIn";
$p="PassworD";
if(($_REQUEST['em1'])==$e && ($_REQUEST['ps1'])==$p){
header('location:profile2.php');

}

elseif (($_REQUEST['em1'])!=$e || ($_REQUEST['ps1'])!=$p) {
echo "THE USER IS NOT 'ADMIN'";

}
}
?>
</div>
</body>
</html>
