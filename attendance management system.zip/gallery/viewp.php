<?php include_once("connection.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.min.css">
	<script src="bootstrap/bootstrap.min.js"></script>
	<script src="bootstrap/jquery.min.js"></script>


</head>
<body background="flower.jpg">



<div class="panel panel-default container">

<div class="panel-heading">
	
	<h1 style="text-align: center;">Attendance Mangement System</h1>

</div>
	

<div class="panel-body">
	
	<a href="view.php" class="btn btn-primary">BACK</a>
	<a href="admin_check.php" class="btn btn-primary pull-right">LOGOUT</a>
	
<form method="post">
<table class="table">
	

<thead>
	
<tr>
	<th>Sr No.</th>
	<th>Name</th>

	<th>Email</th>
	<th>Attendance</th>
</tr>


</thead>

			<?php 

			if($_GET['date']){
				$date=$_GET['date'];

				$query="SELECT register.*,attendance.*
				FROM attendance
				inner join register on attendance.user_id=register.user_id and attendance.date='$date'";
				$result=$link->query($query);

				if($result->num_rows>0){
					$i=0;
					while ($val=$result->fetch_assoc()) {
						$i++;


			 ?>

<tr>
	
	<td><?php echo $i; ?></td>

	<td><?php echo $val['name']; ?></td>

	

	<td><?php echo $val['email']; ?></td>


	<td><?php echo $val['value']; ?>
		
		
	</td>

</tr>
<?php } } } ?>



</div>
	

<div class="panel-footer">
	
	
</div>
	

</div>

</body>
</html>