<?php
include('admin1.php'); // Includes Login Script
if(isset($_SESSION['login_teacher'])){
header("location:profile2.php"); // Redirecting To Profile Page
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
font-family: "Lato", sans-serif;
}

.sidenav {
height: 100%;
width: 0;
position: fixed;
z-index: 1;
top: 0;
left: 0;
background-color: #111;
overflow-x: hidden;
transition: 0.5s;
padding-top: 60px;
}

.sidenav a {
padding: 8px 8px 8px 32px;
text-decoration: none;
font-size: 25px;
color: #818181;
display: block;
transition: 0.3s;
}

.sidenav a:hover {
color: #f1f1f1;
}

.sidenav .closebtn {
position: absolute;
top: 0;
right: 25px;
font-size: 36px;
margin-left: 50px;
}

@media screen and (max-height: 450px) {
.sidenav {padding-top: 15px;}
.sidenav a {font-size: 18px;}
}
</style>
</head>
<body background="pictures/tan.jpg">
<div id="mySidenav" class="sidenav">
 <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
 <a href="index.php">Home</a>
  <a href="about.php">About</a>
   <a href="users.php">Users/Actors</a>
    <a href="overview.php">Overview</a>
		 <a href="requirement.php">System Requirement</a>
	 <a href="contact.php">Contact</a>
	 	 <a href="#">----------------</a>
		  
		  
	 
	  </div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; MENU</span>
<script>
function openNav() {
document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
document.getElementById("mySidenav").style.width = "0";
}
</script>
<meta charset="utf-8">
<title>ADMIN LOGIN</title>
<link rel="stylesheet" href="body.css" >
</head>
<body>


<div class="box">
<h2>Admin  Login</h2>
<form>
<div class="inputbox">
<input type="text" id="name" name="email" required="username" >
<label>username</label>
</div>
<div class="inputbox">
<input type="password"  id="password" name="password" required="password" >
<label>password</label>
</div>
<input type="submit" name="submit"  value="LOGIN" >.<br>.<br>
<b><a href="teach_reg.php">register now</a></b>
</form>
</div>
</body>
</html>
