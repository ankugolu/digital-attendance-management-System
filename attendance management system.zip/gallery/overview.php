<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
font-family: "Lato", sans-serif;
}

.sidenav {
height: 100%;
width: 0;
position: fixed;
z-index: 1;
top: 0;
left: 0;
background-color: #111;
overflow-x: hidden;
transition: 0.5s;
padding-top: 60px;
}

.sidenav a {
padding: 8px 8px 8px 32px;
text-decoration: none;
font-size: 25px;
color: #818181;
display: block;
transition: 0.3s;
}

.sidenav a:hover {
color: #f1f1f1;
}

.sidenav .closebtn {
position: absolute;
top: 0;
right: 25px;
font-size: 36px;
margin-left: 50px;
}

@media screen and (max-height: 450px) {
.sidenav {padding-top: 15px;}
.sidenav a {font-size: 18px;}
}
</style>
</head>
<body>
<div id="mySidenav" class="sidenav">
 <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
 <a href="index.php">Home</a>
  <a href="about.php">About</a>
   <a href="users.php">Users/Actors</a>
    <a href="requirement.php">Software Requirement</a>
	 <a href="contact.php">Contact</a>
	 	 <a href="#">----------------</a>
		 <a href="login.php">login</a>
		  <a href="register.php">register</a>
		  
		  
	  </div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; MENU</span>
<script>
function openNav() {
document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
document.getElementById("mySidenav").style.width = "0";
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Software Requirement</title>
</head>

<body background="pictures/des.jpg">
<table border="5" align="center" style="border-color: black">
	<col width="700">
	<tr>
	<td>
	</td>
	</tr>
	<tr>
	<td>
	</td>
	</tr>
	
	
	<tr>
			<td colspan="3">
				<label style="font-size: 20pt"><h3 align="center"><b>BRIEF OVERVIEW OF THE TECHNOLOGY</b></h3></label>
				</td>
				</tr>
				<tr>
				<td>
<label style="font-size: 16pt"><h3 align="center"><b>Front end: HTML, CSS, JavaScript
</b></h3></label>
				</td>
				</tr>
				<tr>
				<td>
				1.HTML: HTML is used to create and save web document. E.g. Notepad/Notepad++/Dreamweaver
				</td>
				</tr>
				<tr>
				<td>
				2.CSS : (Cascading Style Sheets) Create attractive Layout
				</td>
				</tr>
				<tr>
				<td>
				3.JavaScript: it is a programming language, commonly use with web browsers.
				</td>
				</tr>
				<tr>
				<td>
				4.Bootstrap : for responsive and mobile friendly design.
				</td>
				</tr>
				<tr>
				<td>
				5.JQuery.
				</td>
				</tr>
				<tr>
				<td>
				6.Ajax.
				</td>
				</tr>
				<tr>
				<td>
				<label style="font-size: 16pt"><h3 align="center"><b>
				Back end: PHP, MySQL</b></h3></label>

					</td>
				</tr>
				<tr>
				<td>
				1.PHP: Hypertext Preprocessor (PHP) is a technology that allows software developers to create dynamically generated web pages, in HTML, XML, or other document types, as per client request. PHP is open source software.</td>
				</tr>
				<tr>
				<td>
2.MySQL: MySql is a database, widely used for accessing querying, updating, and managing data in databases.

				</td>
				</tr>
				</table>

			
</body>
</html>
