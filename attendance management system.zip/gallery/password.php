<?php
error_reporting(E_ALL ^ E_NOTICE);
define("DBHOST","localhost");
define("DBUSERNAME","root");
define("DBPASSWORD","");
define("DB","project");

$con = mysqli_connect(DBHOST,DBUSERNAME,DBPASSWORD,DB);
if($con){
	echo "connect"."<br>";
}
else{
	echo "not connect";
}

if($_GET['id'] != ''){
	$sql = "Select * from register where id=".$_GET[user_id];
	$result = mysqli_query($con,$sql);
	$data = mysqli_fetch_assoc($result);
}



if($_SERVER['REQUEST_METHOD']=="POST"){
	$password= $_POST['ps1'];
	
	
	
	
	
	$sql = "Update register set password = '".$password."' where id =".$_GET['user_id'];
	mysqli_query($con,$sql);
	
	echo "Successfully Update password!";
	header("Location:profile.php");
}
if (isset($_POST['submit']))
    {if ($password != $ps2) {
            echo"Your passwords does not match";
            }
			
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PROFILE SETTING</title>
</head>
<body>
<form name="frmEdit" method="post" action="">
<table width="50%" border="1" align="center">
<tr>
<td align="center">PASSWORD SETTING</td>
</tr>
  <tr>
    <td width="193">OLD PASSWORD</td>
    <td width="8">:</td>
    <td width="217"><label>
      <input type="text" name="pass"  value="<?php echo $data['password']; ?>" />
    </label></td>
  </tr>
  <tr>
    <td>NEW PASSWORD</td>
    <td>:</td>
    <td><label>
      <input type="text" name="password" placeholde="TYPE NEW PASSWORD" required />
    </label></td>
  </tr>
  <tr>
    <td>CONFIRM NEW PASSWORD</td>
    <td>:</td>
    <td><label>
      <input type="text" name="ps2" placeholde="RETYPE NEW PASSWORD" required />
    </label></td>
  </tr>
  
  
		
		
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="submit" name="submit" value="Update" /></td>
  </tr>
</table>
</form>
</body>
</html>
